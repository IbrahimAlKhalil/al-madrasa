create function drop_state_tables_generate_script(param_state text, param_schema text DEFAULT 'tiger_data'::text) returns text
    language sql
as
$$
SELECT array_to_string(array_agg('DROP TABLE ' || quote_ident(table_schema) || '.' || quote_ident(table_name) || ';'),E'\n')
	FROM (SELECT * FROM information_schema.tables
	WHERE table_schema = $2 AND table_name like lower($1) || '~_%' ESCAPE '~' ORDER BY table_name) AS foo;
;
$$;

alter function drop_state_tables_generate_script(text, text) owner to postgres;

