create function asgml(tg topology.topogeometry, nsprefix text) returns text
    stable
    language sql
as
$$
SELECT topology.AsGML($1, $2, 15, 1, NULL);
$$;

alter function asgml(topology.topogeometry, text) owner to postgres;

