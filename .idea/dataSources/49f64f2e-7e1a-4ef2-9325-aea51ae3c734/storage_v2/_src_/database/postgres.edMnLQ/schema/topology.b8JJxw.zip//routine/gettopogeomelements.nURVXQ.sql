create function gettopogeomelements(tg topology.topogeometry) returns SETOF topology.topoelement
    stable
    strict
    language plpgsql
as
$$
DECLARE
  toponame varchar;
  rec RECORD;
BEGIN
  toponame = topology.GetTopologyName(tg.topology_id);
  FOR rec IN SELECT * FROM topology.GetTopoGeomElements(toponame,
    tg.layer_id,tg.id) as ret
  LOOP
    RETURN NEXT rec.ret;
  END LOOP;
  RETURN;
END;
$$;

alter function gettopogeomelements(topology.topogeometry) owner to postgres;

