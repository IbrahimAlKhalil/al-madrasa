create function gettopogeomelementarray(tg topology.topogeometry) returns topology.topoelementarray
    stable
    strict
    language plpgsql
as
$$
DECLARE
  toponame varchar;
BEGIN
  toponame = topology.GetTopologyName(tg.topology_id);
  RETURN topology.GetTopoGeomElementArray(toponame, tg.layer_id, tg.id);
END;
$$;

alter function gettopogeomelementarray(topology.topogeometry) owner to postgres;

