create function st_transform(geom geometry, from_proj text, to_proj text) returns geometry
    immutable
    strict
    parallel safe
    cost 10000
    language sql
as
$$
SELECT public.postgis_transform_geometry($1, $2, $3, 0)
$$;

comment on function st_transform(geometry, text, text) is 'args: geom, from_proj, to_proj - Return a new geometry with its coordinates transformed to a different spatial reference system.';

alter function st_transform(geometry, text, text) owner to postgres;

