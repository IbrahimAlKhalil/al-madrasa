create function greatest_hn(fromhn character varying, tohn character varying) returns integer
    immutable
    cost 200
    language sql
as
$$
SELECT greatest(to_number( CASE WHEN trim($1) ~ '^[0-9]+$' THEN $1 ELSE '0' END,'99999999'),to_number(CASE WHEN trim($2) ~ '^[0-9]+$' THEN $2 ELSE '0' END,'99999999') )::integer;
$$;

alter function greatest_hn(varchar, varchar) owner to postgres;

