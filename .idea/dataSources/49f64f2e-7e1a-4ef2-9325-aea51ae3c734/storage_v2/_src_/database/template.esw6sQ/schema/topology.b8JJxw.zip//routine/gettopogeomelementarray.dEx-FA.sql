create function gettopogeomelementarray(tg topogeometry) returns topoelementarray
    stable
    strict
    language plpgsql
as
$$
DECLARE
  toponame varchar;
BEGIN
  toponame = topology.GetTopologyName(tg.topology_id);
  RETURN topology.GetTopoGeomElementArray(toponame, tg.layer_id, tg.id);
END;
$$;

alter function gettopogeomelementarray(topogeometry) owner to postgres;

