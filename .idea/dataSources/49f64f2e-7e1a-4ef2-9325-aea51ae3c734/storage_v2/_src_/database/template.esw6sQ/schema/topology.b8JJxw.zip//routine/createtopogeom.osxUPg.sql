create function createtopogeom(toponame character varying, tg_type integer, layer_id integer) returns topogeometry
    strict
    language sql
as
$$
SELECT topology.CreateTopoGeom($1,$2,$3,'{{0,0}}');
$$;

alter function createtopogeom(varchar, integer, integer) owner to postgres;

