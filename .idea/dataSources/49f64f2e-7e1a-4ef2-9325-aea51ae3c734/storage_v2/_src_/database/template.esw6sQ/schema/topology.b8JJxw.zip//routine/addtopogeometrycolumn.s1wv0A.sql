create function addtopogeometrycolumn(character varying, character varying, character varying, character varying, character varying) returns integer
    language sql
as
$$
SELECT topology.AddTopoGeometryColumn($1, $2, $3, $4, $5, NULL);
$$;

alter function addtopogeometrycolumn(varchar, varchar, varchar, varchar, varchar) owner to postgres;

