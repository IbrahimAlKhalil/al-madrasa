create function asgml(tg topology.topogeometry, nsprefix text, prec integer, options integer, vis regclass) returns text
    language sql
as
$$
SELECT topology.AsGML($1, $2, $3, $4, $5, '');
$$;

alter function asgml(topology.topogeometry, text, integer, integer, regclass) owner to postgres;

